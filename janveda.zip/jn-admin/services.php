<?php include 'header.php' ?>

<body>

    <?php include 'sidebar.php' ?>

    <!-- place main content here -->
       <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Our Service</h4>
                            </div>
                            <div class="content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 1</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 2</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 3</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 4</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 5</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Service 6</label>
                                                <input type="text" class="form-control border-input" placeholder="City" value="Melbourne">
                                            </div>
                                            <div class="form-group">
                                                <textarea rows="3" class="form-control border-input" placeholder="Here can be your description" value="Mike">Oh so, your weak rhyme
                                                    But that's the difference in our opinions.</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Update Profile</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    <!-- end main content -->
    <?php include 'footer.php'; ?>  
    </div>


</body>

   
</html>
